from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import uuid

from db import SessionLocal
from models import (
    Producto,
    Movimiento,
    Usuario,
    Lote,
    InventarioLote,
    MovimientoLoteDetalle,
)

from schemas import (
    MovimientoCreate,
    MovimientoOut,
)

from deps import get_db, require_roles


app = FastAPI()

# =============================
# HEALTH CHECK
# =============================
@app.get("/")
def root():
    return {"status": "ok"}


# =============================
# LOGIN TEST (SIMPLE)
# =============================
@app.get("/ping")
def ping():
    return {"message": "pong"}


# =============================
# PRODUCTOS
# =============================
@app.get("/productos")
def get_productos(db: Session = Depends(get_db)):
    return db.query(Producto).all()


# =============================
# MOVIMIENTOS + UUID LOTES
# =============================
@app.post("/movimientos", response_model=MovimientoOut)
def crear_movimiento(
    payload: MovimientoCreate,
    db: Session = Depends(get_db),
    user: Usuario = Depends(require_roles(["admin", "manager", "tecnico"]))
):
    movimiento = Movimiento(
        producto_id=payload.producto_id,
        tipo_movimiento="AUTO",
        origen_tipo=payload.origen_tipo,
        destino_tipo=payload.destino_tipo,
        zona_origen=payload.zona_origen,
        zona_destino=payload.zona_destino,
        tamano_origen=payload.tamano_origen,
        tamano_destino=payload.tamano_destino,
        cantidad=payload.cantidad,
        created_by=user.username
    )

    db.add(movimiento)
    db.flush()

    # =============================
    # ENTRADA AL VIVERO → NUEVO UUID
    # =============================
    if payload.origen_tipo != "vivero" and payload.destino_tipo == "vivero":
        nuevo_uuid = str(uuid.uuid4())

        lote = Lote(
            uuid_lote=nuevo_uuid,
            producto_id=payload.producto_id,
            cantidad_inicial=payload.cantidad,
            zona_inicial=payload.zona_destino,
            created_by=user.username
        )
        db.add(lote)

        inventario = InventarioLote(
            uuid_lote=nuevo_uuid,
            producto_id=payload.producto_id,
            zona=payload.zona_destino,
            tamano=payload.tamano_destino,
            cantidad_disponible=payload.cantidad
        )
        db.add(inventario)

        detalle = MovimientoLoteDetalle(
            movimiento_id=movimiento.id,
            uuid_lote=nuevo_uuid,
            producto_id=payload.producto_id,
            zona_destino=payload.zona_destino,
            tamano_destino=payload.tamano_destino,
            cantidad=payload.cantidad
        )
        db.add(detalle)

    # =============================
    # MOVIMIENTO DENTRO DEL VIVERO
    # =============================
    elif payload.origen_tipo == "vivero":
        restante = payload.cantidad

        inventarios = db.query(InventarioLote).filter(
            InventarioLote.producto_id == payload.producto_id,
            InventarioLote.zona == payload.zona_origen,
            InventarioLote.tamano == payload.tamano_origen,
            InventarioLote.cantidad_disponible > 0
        ).all()

        if not inventarios:
            raise HTTPException(status_code=400, detail="No hay stock disponible")

        for inv in inventarios:
            if restante <= 0:
                break

            usar = min(inv.cantidad_disponible, restante)
            inv.cantidad_disponible -= usar

            # mover al destino
            destino = db.query(InventarioLote).filter(
                InventarioLote.uuid_lote == inv.uuid_lote,
                InventarioLote.zona == payload.zona_destino,
                InventarioLote.tamano == payload.tamano_destino
            ).first()

            if destino:
                destino.cantidad_disponible += usar
            else:
                db.add(InventarioLote(
                    uuid_lote=inv.uuid_lote,
                    producto_id=payload.producto_id,
                    zona=payload.zona_destino,
                    tamano=payload.tamano_destino,
                    cantidad_disponible=usar
                ))

            db.add(MovimientoLoteDetalle(
                movimiento_id=movimiento.id,
                uuid_lote=inv.uuid_lote,
                producto_id=payload.producto_id,
                zona_origen=payload.zona_origen,
                zona_destino=payload.zona_destino,
                tamano_origen=payload.tamano_origen,
                tamano_destino=payload.tamano_destino,
                cantidad=usar
            ))

            restante -= usar

        if restante > 0:
            raise HTTPException(status_code=400, detail="Stock insuficiente")

    db.commit()
    db.refresh(movimiento)
    return movimiento


# =============================
# LISTAR MOVIMIENTOS
# =============================
@app.get("/movimientos")
def listar_movimientos(db: Session = Depends(get_db)):
    return db.query(Movimiento).all()


# =============================
# TRAZABILIDAD POR UUID
# =============================
@app.get("/lotes/{uuid_lote}")
def get_lote(uuid_lote: str, db: Session = Depends(get_db)):
    lote = db.query(Lote).filter(Lote.uuid_lote == uuid_lote).first()

    if not lote:
        raise HTTPException(status_code=404, detail="Lote no encontrado")

    detalles = db.query(MovimientoLoteDetalle).filter(
        MovimientoLoteDetalle.uuid_lote == uuid_lote
    ).all()

    return {
        "uuid": uuid_lote,
        "producto_id": lote.producto_id,
        "cantidad_inicial": lote.cantidad_inicial,
        "movimientos": [
            {
                "movimiento_id": d.movimiento_id,
                "zona_origen": d.zona_origen,
                "zona_destino": d.zona_destino,
                "cantidad": d.cantidad
            }
            for d in detalles
        ]
    }