from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from db import Base

# =========================
# PRODUCTOS
# =========================

class Producto(Base):
    __tablename__ = "productos"

    id = Column(Integer, primary_key=True, index=True)
    nombre_cientifico = Column(String)
    nombre_natural = Column(String)
    categoria = Column(String)
    subcategoria = Column(String)
    stock_minimo = Column(Integer, default=5)


# =========================
# MOVIMIENTOS
# =========================

class Movimiento(Base):
    __tablename__ = "movimientos"

    id = Column(Integer, primary_key=True, index=True)
    producto_id = Column(Integer, ForeignKey("productos.id"))
    cantidad = Column(Integer)

    origen_tipo = Column(String)
    destino_tipo = Column(String)

    zona_origen = Column(String, nullable=True)
    zona_destino = Column(String, nullable=True)

    tamano_origen = Column(String, nullable=True)
    tamano_destino = Column(String, nullable=True)

    fecha_movimiento = Column(DateTime, default=datetime.utcnow)

    producto = relationship("Producto")
    detalles = relationship("MovimientoLoteDetalle", back_populates="movimiento")


# =========================
# LOTES (UUID)
# =========================

class Lote(Base):
    __tablename__ = "lotes"

    id = Column(Integer, primary_key=True)
    uuid = Column(String, unique=True, index=True)

    producto_id = Column(Integer, ForeignKey("productos.id"))
    cantidad_inicial = Column(Integer)

    fecha_entrada = Column(DateTime, default=datetime.utcnow)

    producto = relationship("Producto")


# =========================
# INVENTARIO POR LOTE
# =========================

class InventarioLote(Base):
    __tablename__ = "inventario_lote"

    id = Column(Integer, primary_key=True)

    lote_id = Column(Integer, ForeignKey("lotes.id"))
    producto_id = Column(Integer, ForeignKey("productos.id"))

    zona = Column(String)
    tamano = Column(String)

    cantidad = Column(Integer)

    lote = relationship("Lote")
    producto = relationship("Producto")


# =========================
# DETALLE MOVIMIENTO-LOTE
# =========================

class MovimientoLoteDetalle(Base):
    __tablename__ = "movimiento_lote_detalle"

    id = Column(Integer, primary_key=True)

    movimiento_id = Column(Integer, ForeignKey("movimientos.id"))
    lote_id = Column(Integer, ForeignKey("lotes.id"))

    cantidad = Column(Integer)

    movimiento = relationship("Movimiento", back_populates="detalles")
    lote = relationship("Lote")